import React , {Component} from 'react';

class About extends  Component{
    constructor(props){
        super(props);
    }
    render() {
        return (
            <div>
                <div className='container'>
                    <div className="jumbotron mt-4 bg-light">
                        <h1 className="display-4 text-primary">About Us</h1>
                        <p className="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias amet fugiat libero quas? Accusamus adipisci asperiores aspernatur aut corporis culpa cum dolorum earum excepturi fugiat iusto nam, possimus quod. Aspernatur consequatur culpa cumque cupiditate esse minima nostrum quis quod repellat!</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. At doloremque exercitationem expedita possimus quod. Facere, magni, quisquam. Cum cupiditate earum eos odit ratione! Id molestiae nisi reprehenderit. A accusamus ad distinctio dolores ea eaque facilis fugiat illo magnam mollitia necessitatibus nihil pariatur porro reiciendis, reprehenderit repudiandae similique veniam voluptate voluptatem?</p>
                        <p className="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias amet fugiat libero quas? Accusamus adipisci asperiores aspernatur aut corporis culpa cum dolorum earum excepturi fugiat iusto nam, possimus quod. Aspernatur consequatur culpa cumque cupiditate esse minima nostrum quis quod repellat!</p>
                        <hr className="my-4"/>
                        <p>It uses utility classes for typography and spacing to space content out within the larger
                            container.</p>
                        <a className="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
                    </div>
                </div>
            </div>
        );
    }
}

export default About;