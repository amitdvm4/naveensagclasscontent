// Normal Log Message
console.log('Iam normal Log Message');

// Information Message
console.info('Iam an information Message');

// Warning Message
console.warn('Iam a Warning Message');

// Error Message
console.error('Iam an Error Message');