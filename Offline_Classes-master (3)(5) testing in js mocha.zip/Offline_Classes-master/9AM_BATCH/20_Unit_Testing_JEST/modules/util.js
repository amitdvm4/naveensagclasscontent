let countZeros = (str) => {
    let count = 0;
    for(let i=0; i<str.length ; i++){
        let ch = str.charAt(i);
        if(ch === 'o' || ch === 'O'){
            count++;
        }
    }
    return count;
};

let reverseString = (str) => {
    let tempString = '';
    for(let i= str.length-1; i >= 0; i--){
        let ch = str.charAt(i);
        tempString += ch;
    }
    return tempString;
};

let isPalindrome = (str) => {
    return str === reverseString(str);
};

let convertToPalindrome = (str) => {
    return str + reverseString(str.substr(0,str.length-1));
};

let triangleOne = (str) => {
    let tempString = '';
    for(let i=1; i<= str.length; i++){
        tempString += `${str.substr(0,i)} \n`;
    }
    return tempString;
};

let addSpace = (number) => {
    let tempSpace = '';
    for(let i=1; i<=number; i++){
        tempSpace += ' ';
    }
    return tempSpace;
};

let triangleTwo = (str) => {
    let tempString = '';
    for(let i=0; i<=str.length-1; i++){
        tempString += `${addSpace(i)}${str.substr(i)} \n`;
    }
    return tempString;
};

let triangleThree = (str) => {
    let tempString = '';
    for(let i=str.length; i >= 1; i--){
        tempString += `${str.substr(0,i)} \n`;
    }
    return tempString;
};

let numberArray = ['ZERO' , 'ONE', 'TWO' , 'THREE' , 'FOUR' , 'FIVE' , 'SIX' , 'SEVEN', 'EIGHT' , 'NINE'];
let convertToWordNumber = (str) => {
    let tempString = '';
    for(let i=0; i<str.length; i++) {
        let digit = Number.parseInt(str.charAt(i));
        tempString += ` ${numberArray[digit]} `;
    }
    return tempString;
};

module.exports = {
    reverseString,
    triangleThree,
    triangleOne,
    triangleTwo,
    convertToPalindrome,
    convertToWordNumber
};