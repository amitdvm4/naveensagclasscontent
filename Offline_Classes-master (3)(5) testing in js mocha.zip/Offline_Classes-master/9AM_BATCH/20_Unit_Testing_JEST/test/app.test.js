const app = require('../app');
const util = require('../modules/util');

describe('app.js', function () {

    describe('sum() function', function () {

        // test case 1
        test('should return 30 for 10 , 20', () => {
            expect(app.sum(10,20)).toBe(30);
        });

        // test case 2
        test('should be above 40 for 30, 20', () => {
            expect(app.sum(30,20)).toBeGreaterThan(40);
        });

        // test case 3
        test('should be below 40 for 10, 20', () => {
            expect(app.sum(10,20)).toBeLessThan(40);
        });

    });

    // reverseString()
    describe('reverseString() function', function () {

        // test case 1
        test('should return the reverse String', () => {
            expect(app.reverseString('Hello')).toBe('olleH');
        });

        // test case 2
        test('should not return the same String', () => {
            expect(app.reverseString('Hello')).not.toBe('Hello');
        });

        // test case 3
        test('should return the same length', () => {
            let msg = 'Hello';
            expect(app.reverseString(msg).length).toBe(msg.length);
        });
    });
});