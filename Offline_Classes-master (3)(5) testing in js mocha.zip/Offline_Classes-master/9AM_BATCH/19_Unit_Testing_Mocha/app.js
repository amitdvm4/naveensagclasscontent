let greet = () => {
    return 'Hello';
};

let sum = (a , b) => {
    return a + b;
};

let reverseString = (str) => {
    let tempString = '';
    for(let i=str.length-1; i>=0; i--){
        tempString += `${str.charAt(i)}`;
    }
    return tempString;
};

module.exports = {
    greet,
    sum,
    reverseString
};