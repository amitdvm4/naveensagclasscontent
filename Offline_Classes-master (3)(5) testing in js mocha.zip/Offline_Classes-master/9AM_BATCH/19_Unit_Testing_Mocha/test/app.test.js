const app = require('../app');
const assert = require('chai').assert;

describe('app.js', function () {

    // greet()
    describe('greet() function', function () {

        let actualValue = app.greet();

        // Test Case 1
        it('should return a Hello String', function () {
            assert.equal(actualValue,'Hello');
        });

        // Test Case 2
        it('should not equals to hello String', function () {
            assert.notEqual(actualValue,'hello');
        });

        // Test Case 3
        it('should return a string', function () {
            assert.typeOf(actualValue, 'string');
        });

        // Test Case 4
        it('should return a string with the length 5', function () {
            assert.equal(actualValue.length, 5);
        });

    });
    
    // sum()
    describe('sum() function', function () {
        
        // test case 1
        it('should should return 30 for 10 , 20', function () {
            assert.equal(app.sum(10,20) , 30);
        });

        // test  case 2
        it('should be above 40 for 30 , 20', function () {
            assert.isAbove(app.sum(30,20), 40);
        });

        // test  case 3
        it('should be below 40 for 10 , 10', function () {
            assert.isBelow(app.sum(10,10), 40);
        });
    });
    
    // reverseString()
    describe('reverseString() function', function () {

        // test case 1
        it('should return a reverse String', function () {
            assert.equal(app.reverseString('Hello'),'olleH');
        });

        // test case 2
        it('should return the same String', function () {
            assert.notEqual(app.reverseString('Hello'),'Hello');
        });

        // test case 3
        it('should return the same length', function () {
            let str = 'Hello';
            assert.equal(app.reverseString(str).length , str.length);
        });

    });
});