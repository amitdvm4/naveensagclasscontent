var empdetails =[
{
	name:"sudheer",
	gender: "male",
	location :"hyd",
	age : 25
},
{
	
	name:"sudheer",
	gender: "male",
	location :"hyd",
	age : 25
},
{
	
	name:"sudheer",
	gender: "male",
	location :"hyd",
	age : 25
}
]


function showempdetails(empdetail)
{

	 var litag = document.createElement("li");
	 litag.setAttribute("class", 'eItems');

	 var imgTag = document.createElement("img");
	 imgTag.setAttribute("src",'images.jpg');
	 litag.appendChild(imgTag);

	 var div1tag =document.createElement("div");
	 div1tag . innerText = "empolyee Name" + empdetail.name;
	 litag.appendChild(div1tag);

	 var div2tag = document.createElement("div");
	 div2tag. innerText = "gender" +empdetail.gender;
	 litag.appendChild(div2tag);

	 var div3tag = document.createElement("div");
	 div3tag.innerText = "location" + empdetail.location;
	 litag.appendChild(div3tag);


	  var div4tag = document.createElement("div");
	 div4tag.innerText = "age" +empdetail.age;
	 litag.appendChild(div4tag);

	 document.querySelector(".container").appendChild(litag);
	 console.log(litag);
	}


	 	for( var i=0; i < empdetails.length; i++)
	 	{
	 		showempdetails(empdetails[i]);
	 	}



