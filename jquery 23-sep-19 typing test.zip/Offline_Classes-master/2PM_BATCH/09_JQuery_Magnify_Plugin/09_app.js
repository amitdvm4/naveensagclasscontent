$(document).ready(function() {
    $('.zoomple').zoomple({
        blankURL : 'images/blank.gif',
        bgColor : '#90D5D9',
        loaderURL : 'images/loader.gif',
        offset : {x:-150,y:-150},
        zoomWidth : 300,
        zoomHeight : 300,
        roundedCorners : true
    });
});