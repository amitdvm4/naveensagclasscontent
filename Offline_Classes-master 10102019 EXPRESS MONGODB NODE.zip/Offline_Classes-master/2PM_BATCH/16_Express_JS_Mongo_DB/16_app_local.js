const MongoClient = require('mongodb').MongoClient;

// Connection URL
const url = 'mongodb://127.0.0.1:27017';

// Database Name
const dbName = 'infosys-db';

// Create a new MongoClient
const client = new MongoClient(url);

// Use connect method to connect to the Server
client.connect(function(err) {
    const db = client.db(dbName);
    console.log("Connected successfully to Mongo DB ");

    /* ---------------------------------- START HERE --------------------- */
    

    /* ---------------------------------- END HERE --------------------- */


});


