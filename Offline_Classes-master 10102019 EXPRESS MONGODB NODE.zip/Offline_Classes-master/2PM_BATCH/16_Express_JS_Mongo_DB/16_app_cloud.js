// https://docs.mongodb.com/ecosystem/drivers/node/
const MongoClient = require('mongodb').MongoClient;
const url = "<<MONGODB-CLOUD-URL>>";
const client = new MongoClient(url, { useNewUrlParser: true });

// Database Name
const dbName = 'infosys-db';

client.connect(err => {
    const db = client.db(dbName);
    console.log('Connected to MongoDB Atlas Successfully');

    /* -------------------------------- START HERE ---------------------------- */

    db.collection('employee').deleteOne({name : 'John'}, (err , r) => {
        console.log('Record is Deleted');
        client.close();
    });


    /* -------------------------------- END HERE ---------------------------- */

});