<?php include("header.php");?>
<?php 
if(isset($_SESSION['logintrue']))
{
	?>
	<div class="container">
		<div class="row">
			<div class="col">
				<h1>View Employees</h1>
		
		
		<?php 
		
		if(isset($_COOKIE['success']))
		{
			echo "<p>".$_COOKIE['success']."</p>";
		}
		
		$res=mysqli_query($con,"select *from employee");
		if(mysqli_num_rows($res)>0)
		{
			?>
			<table class="table">
			<tr>
				<th>EID</th>
				<th>Name</th>
				<th>Salary</th>
				<th>City</th>
				<th>Designation</th>
				<th>Join date</th>
				<th>Action</th>
			</tr>
			<?php 
			while($row=mysqli_fetch_assoc($res))
			{
				?>
				<tr>
				<td><?php echo $row['eid'];?></td>
				<td><?php echo $row['empname'];?></td>
				<td><?php echo $row['salary'];?></td>
				<td><?php echo $row['city'];?></td>
				<td><?php echo $row['designation'];?></td>
				<td><?php echo date("Y-m-d",strtotime($row['date_created'])); ?></td>
				<td>
					<a href="edit_emp.php?token=<?php echo $row['eid'];?>">Edit</a> | 
<a onclick="deleteEmp(<?php echo $row['eid'] ?>)" href="javascript:void(0)">Delete</a>
				</td>
			</tr>
				<?php
			}
			?>
		</table>
			<?php
		}
		else
		{
			echo "<p>Sorry! No records found</p>";
		}
		
		?>
		
		
		<script>
			function deleteEmp(id)
			{
				var c=confirm("Do you want to delete?");
				if(c==true)
				{
					window.location="delete_emp.php?token="+id;
				}
			}
		</script>
			</div>
		</div>
	</div>
	<?php
}
else
{
	header("Location:login.php");
}
?>
<?php include("footer.php");?>