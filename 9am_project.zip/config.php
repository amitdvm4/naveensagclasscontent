<?php 
// Product Details 
// Minimum amount is $0.50 US 
$itemName = "Demo Product"; 
$itemNumber = "PN12345"; 
$itemPrice = 25*5; 
$currency = "USD"; 
 
// Stripe API configuration  
define('STRIPE_API_KEY', 'Your Key'); 
define('STRIPE_PUBLISHABLE_KEY', 'Your key'); 
  
// Database configuration  
define('DB_HOST', 'localhost'); 
define('DB_USERNAME', 'root'); 
define('DB_PASSWORD', ''); 
define('DB_NAME', '9am');