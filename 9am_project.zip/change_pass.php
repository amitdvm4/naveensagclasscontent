<?php include("header.php");?>

<?php 
if(isset($_SESSION['logintrue']))
{
	$token=$_SESSION['logintrue'];
	$res=mysqli_query($con,"select profile_pic,passowrd,username from users where token='$token'");	
	$row=mysqli_fetch_assoc($res);
	?>
		<div class="container">
			<div class="row">
				<div class="col">
					<h1><?php echo $row['username']?> | Change password</h1>
				
				<?php 
				if($row['profile_pic']!="")
				{
				?>
					<img src='profiles/<?php echo $row['profile_pic']?>' height="50" width="50">
					<a href='avatar.php'>Upload</a>
				<?php }
				else
				{
					?>
					<img src='profiles/avatar.png' height="50" width="50">
					<a href='avatar.php'>Upload</a>
				<?php
				}
				?>
				
				<?php 
				if(isset($_COOKIE['success']))
				{
					echo $_COOKIE['success'];
				}
				
				if(isset($_POST['update']))
				{
					$opwd=$_POST['opwd'];
					$npwd=$_POST['npwd'];
					$cnpwd=$_POST['cnpwd'];
					
					if($npwd==$cnpwd)
					{
						if(password_verify($opwd,$row['passowrd']))
						{
							$npwd=password_hash($npwd,PASSWORD_DEFAULT);
							mysqli_query($con,"update users set passowrd='$npwd' where token='$token'");
							
							if(mysqli_affected_rows($con)>0)
							{
								setcookie("success","<p>Password Updated Succcessfully</p>",time()+2);
						header("Location:change_pass.php");
							}
							else
							{
								echo "<p>Unable to update password, try again</p>";
							}
							
						}
						else
						{
							echo "<p>Old password does not macthed</p>";
						}
					}
					else
					{
						echo "<p>New password and confirm password dos not matched</p>";
					}
					
				}
				?>
				
				<form method="POST" action="" onsubmit="return validateCP()">
				
					<table class="table">
				<tr>
					<td>Old Password</td>
					<td><input type="password" name="opwd" id="opwd" class="form-control"></td>
				</tr>
				<tr>
					<td>New Password</td>
					<td><input type="password" name="npwd" id="npwd" class="form-control"></td>
				</tr>
				<tr>
					<td>Confirm New Password</td>
					<td><input type="password" name="cnpwd" id="cnpwd" class="form-control"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="update" value="Update" class="btn btn-success">
					
					</td>
				</tr>
			</table>
					
				</form>
				
				<script>
					function validateCP()
					{
						//Password validation
			if(document.getElementById("opwd").value=="")
			{
				alert("Enter Old Password");
				return false;
			}
						
			if(document.getElementById("npwd").value=="")
			{
				alert("Enter New Password");
				return false;
			}
			if(document.getElementById("cnpwd").value=="")
			{
				alert("Enter Confirm Password");
				return false;
			}
					}
				</script>
				</div>
			</div>
		</div>
	<?php
}
else
{
	header("Location:login.php");
}
?>


<?php include("footer.php");?>