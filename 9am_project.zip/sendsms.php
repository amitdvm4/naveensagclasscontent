<?php
	if(isset($_POST['submit']))
	{
		// Account details
		$apiKey = urlencode('Your api key');
		
		// Message details
		$mobile=$_POST['mobile'];
		$numbers = array($mobile);
		$sender = urlencode('TXTLCL');
		$otp=substr(str_shuffle(1234567890),2,6);
		$message = rawurlencode('you otp is:'.$otp);
	 
		$numbers = implode(',', $numbers);
	 
		// Prepare data for POST request
		$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
	 
		// Send the POST request with cURL
		$ch = curl_init('https://api.textlocal.in/send/');
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$response = curl_exec($ch);
		curl_close($ch);
		
		// Process your response here
		$obj= json_decode($response);
		
		if($obj->status=="success")
		{
			echo "<p>SMS sent successfully</p>";
		}
		else
		{
			echo "<p>Sorry! Unable to send an sms</p>";
		}
	}
?>

<form method="POST" action="">
	Mobile:<input type="" name="mobile">
	<input type="submit" name="submit" value="Send">
</form>

