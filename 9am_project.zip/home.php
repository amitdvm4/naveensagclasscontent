<?php include("header.php");
if(isset($_SESSION['logintrue']))
{
	$token=$_SESSION['logintrue'];
	
	$res=mysqli_query($con,"select * from users where token='$token'");
	
	$row=mysqli_fetch_assoc($res);
	

?>
	<div class="container">
		<div class="row">
			<div class="col">
				<h1>Welcome to <?php echo $row['username'];?></h1>
				<?php 
				if($row['profile_pic']!="")
				{
				?>
					<img src='profiles/<?php echo $row['profile_pic']?>' height="50" width="50">
					<a href='avatar.php'>Upload</a>
				<?php }
				else
				{
					?>
					<img src='profiles/avatar.png' height="50" width="50">
					<a href='avatar.php'>Upload</a>
				<?php
				}
				?>
				<table class="table">
<tr>
	<td>Id</td>
	<td><?php echo $row['id'];?></td>
</tr>
<tr>
	<td>Username</td>
	<td><?php echo $row['username'];?></td>
</tr>
<tr>
	<td>Email</td>
	<td><?php echo $row['email'];?></td>
</tr>
<tr>
	<td>Mobile</td>
	<td><?php echo $row['mobile'];?></td>
</tr>
<tr>
	<td>Gender</td>
	<td><?php echo $row['gender'];?></td>
</tr>
<tr>
	<td>State</td>
	<td><?php echo $row['state'];?></td>
</tr>
<tr>
	<td>DOB</td>
	<td><?php echo $row['dob'];?></td>
</tr>
<tr>
	<td>Status</td>
	<td>Active</td>
</tr>
<tr>
	<td>Date of Join</td>
<td><?php echo date("l, dS M Y",strtotime($row['doj']));?></td>
</tr>
					
					
				</table>
			</div>
		</div>
	</div>
	
<?php
}
else
{
	header("Location:login.php");
}
 include("footer.php");?>