<?php 
$con=mysqli_connect("localhost","root","","9am") or die("Unable to connect");
?>